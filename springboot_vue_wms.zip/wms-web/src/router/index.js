// 这是一个基于Vue Router的路由配置文件（index.js）。以下是关键点和说明：
// 路由配置：
// routes数组定义了整个应用的路由配置。
// /路径指向登录页面，/Index路径指向主页面，同时有子路由/Home指向首页。
// 注释掉的部分是一些暂时未启用的路由配置。
// 动态导入组件：
// 使用import()动态导入组件，以避免一开始就加载所有组件，优化性能。
// 嵌套路由：
// 主页面 (/Index) 有子路由 Home，这样的嵌套路由可以帮助组织和管理页面的层次结构。
// 路由元信息（meta）：
// 使用meta字段定义了一些路由的元信息，如页面标题 (title)。
// 路由模式：
// 使用了mode: 'history'，这是Vue Router提供的历史模式，可以去掉URL中的#。
// resetRouter：
// 提供了一个 resetRouter 函数，用于重置路由。这在动态添加路由时可能会用到。
// 修改 VueRouter.prototype.push：
// 重写了 VueRouter.prototype.push 方法，用于捕捉路由跳转错误，防止在控制台产生不必要的错误输出。
// import VueRouter from 'vue-router';

const routes = [
    {
        path:'/',
        name:'login',
        component:()=>import('../components/Login')
    },
    {
        path:'/Index',
        name:'index',
        component:()=>import('../components/Index'),
        children:[
            {
                path:'/Home',
                name:'home',
                meta:{
                    title:'首页'
                },
                component:()=>import('../components/Home')
            },
            /*{
                path:'/Admin',
                name:'admin',
                meta:{
                    title:'管理员管理'
                },
                component:()=>import('../components/admin/AdminManage.vue')
            },
            {
                path:'/User',
                name:'user',
                meta:{
                    title:'用户管理'
                },
                component:()=>import('../components/user/UserManage.vue')
            },*/
        ]
    }
]

const router = new VueRouter({
    mode:'history',
    routes
})

export function resetRouter() {
    router.matcher = new VueRouter({
        mode:'history',
        routes: []
    }).matcher
}
const VueRouterPush = VueRouter.prototype.push
VueRouter.prototype.push = function push (to) {
    return VueRouterPush.call(this, to).catch(err => err)
}
export  default router;