// 导入 Vue、Vuex 以及路由相关内容：
// import vue from 'vue' 导入 Vue 对象。
// import Vuex from 'vuex' 导入 Vuex。
// import router, { resetRouter } from "../router"; 导入路由配置和路由重置方法。
// 使用 Vuex：
// 通过 Vue.use(Vuex) 启用 Vuex 插件。
// addNewRoute 函数：
// addNewRoute 函数用于根据菜单列表动态添加路由。
// 它接受菜单列表作为参数，遍历现有的路由配置，找到主页面 (/Index) 的配置，然后根据菜单列表动态生成子路由，并将这些新的子路由添加到路由配置中。
// 最后，通过 resetRouter() 重置路由，再通过 router.addRoutes(routes) 添加新的路由。
// Vuex Store：
// state 对象中有一个 menu 属性，用于存储菜单列表的状态。
// mutations 中定义了 setMenu 方法，用于设置菜单并调用 addNewRoute 来添加对应的路由。
// getters 中定义了 getMenu 方法，用于获取菜单状态。
// 默认导出 Vuex 实例：
// 通过 export default new Vuex.Store({...}) 导出一个 Vuex 的实例。

import vue from 'vue'
import Vuex from 'vuex'
import router,{resetRouter} from "../router";
vue.use(Vuex)

function addNewRoute(menuList) {
    console.log(menuList)
    let routes = router.options.routes
    console.log(routes)
    routes.forEach(routeItem=>{
        if(routeItem.path=="/Index"){
            menuList.forEach(menu=>{
                let childRoute =  {
                    path:'/'+menu.menuclick,
                    name:menu.menuname,
                    meta:{
                        title:menu.menuname
                    },
                    component:()=>import('../components/'+menu.menucomponent)
                }

                routeItem.children.push(childRoute)
            })
        }
    })

    resetRouter()
    router.addRoutes(routes)
}

export default new Vuex.Store({
    state: {
        menu: []
    },
    mutations: {
        setMenu(state,menuList) {
            state.menu = menuList

            addNewRoute(menuList)
        }
    },
    getters: {
        getMenu(state) {
            return state.menu
        }
    }
})