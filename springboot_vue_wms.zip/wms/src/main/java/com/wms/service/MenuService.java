package com.wms.service;

import com.wms.entity.Menu;
import com.baomidou.mybatisplus.extension.service.IService;

public interface MenuService extends IService<Menu> {

}
