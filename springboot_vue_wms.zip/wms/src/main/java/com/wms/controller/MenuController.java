package com.wms.controller;

import com.wms.common.Result;
import com.wms.entity.Menu;
import com.wms.entity.User;
import com.wms.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping("/menu")
public class MenuController {

    @Autowired
    private MenuService menuService;
//    使用 @GetMapping("/list") 注解表示这个方法处理 HTTP GET 请求，并处理获取菜单列表的操作。
//    使用 @RequestParam 注解获取请求参数中的角色 ID (roleId)。
//    调用 menuService.lambdaQuery().like(Menu::getMenuright, roleId).list() 查询具有指定角色权限的菜单列表。
//    将查询结果封装成 Result 对象返回。
    @GetMapping("/list")
    public Result list(@RequestParam String roleId){
        List list = menuService.lambdaQuery().like(Menu::getMenuright,roleId).list();
        return Result.suc(list);
    }
}
